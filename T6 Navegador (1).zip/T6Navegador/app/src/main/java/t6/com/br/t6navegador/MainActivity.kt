package t6.com.br.t6navegador

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import t6.com.br.t6navegador.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)

        var paginaAtual = ""
        var paginaAnterior = ""
        var paginaProxima = ""
        var paginaNavegar = ""

        val listaFrases = arrayListOf("A vida trará coisas boas se tiveres paciência",
                "Não compense na ira o que lhe falta na razão",
                "Defeitos e virtudes são apenas dois lados da mesma moeda",
                "Siga os bons e aprenda com eles",
                "Não importa o tamanho da montanha, ela não pode tapar o sol",
                "A adversidade é um espelho que reflete o verdadeiro eu",
                "Você é jovem apenas uma vez. Depois precisa inventar outra desculpa",
                "A paciência na adversidade é o sinal de um coração sensível",
                "A sorte favorece a mente bem preparada")

        binding.web.settings.javaScriptEnabled = true

        binding.btVoltar.setOnClickListener{

            if(paginaAnterior!=""){
                binding.web.loadUrl("$paginaAnterior")
                binding.web.webViewClient = WebViewClient()
                var paginaAux = paginaAtual
                paginaAtual = paginaAnterior
                paginaProxima = paginaAux
            }else{
                Toast.makeText(this,"Sem páginas anteriores", Toast.LENGTH_LONG).show()
            }

        }

        binding.btAvancar.setOnClickListener{
            if(paginaProxima != ""){
                binding.web.loadUrl("$paginaProxima")
                binding.web.webViewClient = WebViewClient()
                var paginaAux = paginaAtual
                paginaAtual = paginaProxima
                paginaAnterior = paginaAux
            }else{
                Toast.makeText(this,"Sem páginas próximas", Toast.LENGTH_LONG).show()
            }

        }

        binding.btReload.setOnClickListener{
            binding.web.loadUrl("$paginaAtual")
            binding.web.webViewClient = WebViewClient()
        }



        binding.edtUrl.setOnEditorActionListener{v, actionId, event ->
            if(actionId == EditorInfo.IME_ACTION_NEXT){

                paginaNavegar = binding.edtUrl.text.toString().trim().toLowerCase()
                if(paginaNavegar == ""){
                    Toast.makeText(this,"É necessário informar uma url", Toast.LENGTH_LONG).show()
                }else if(!paginaAtual.contains("https://")){
                    paginaNavegar = "https://$paginaNavegar"

                    if(paginaAtual != paginaNavegar){
                        paginaAnterior = paginaAtual
                        paginaAtual = paginaNavegar
                    }
                    binding.web.loadUrl("$paginaNavegar")
                    binding.web.webViewClient = WebViewClient()
                    paginaAtual = paginaNavegar

                }else{
                    if(paginaAtual != paginaNavegar){
                        paginaAnterior = paginaAtual
                        paginaAtual = paginaNavegar
                    }
                    binding.web.loadUrl("$paginaAtual")
                    binding.web.webViewClient = WebViewClient()
                    paginaAtual = paginaNavegar
                }


                true
            }else{
                false
            }
        }

        binding.btCookie.setOnClickListener{
            val alert = AlertDialog.Builder(this)
            alert.setTitle("Biscoito da sorte")
            val mensagem = listaFrases.random()
            alert.setMessage("$mensagem")
            alert.show()
        }

        binding.btConverter.setOnClickListener{
            showModal()
        }





    }

    private fun showModal(){
        val buider = AlertDialog.Builder(this)
        val inflater = layoutInflater
        val dialogLayout = inflater.inflate(R.layout.modal, null)
        val ediNumber = dialogLayout.findViewById<EditText>(R.id.edtKm)
        val buttonCalcular = dialogLayout.findViewById<Button>(R.id.btCalcular)
        val txMetros = dialogLayout.findViewById<TextView>(R.id.txtMetros)
        val txCentimetros = dialogLayout.findViewById<TextView>(R.id.txtCentimetros)
        val txMilimetros = dialogLayout.findViewById<TextView>(R.id.txtMilimetros)



        buttonCalcular.setOnClickListener {
            val metros = ediNumber.text.toString().trim().toDouble() * 1000
            val centimetros = ediNumber.text.toString().trim().toDouble() * 100000
            val milimetros = ediNumber.text.toString().trim().toDouble() * 1000000
            txMetros.text = "$metros m"
            txCentimetros.text = "$centimetros cm"
            txMilimetros.text = "$milimetros mm"
        }
        with(buider){


            setView(dialogLayout)
            show()
        }
    }


}
